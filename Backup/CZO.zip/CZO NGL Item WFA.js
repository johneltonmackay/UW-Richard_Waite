function revrec()
{
	nlapiSetFieldValue('directrevenueposting', 'T');
	nlapiSetFieldValue('revrecforecastrule', 4);
}