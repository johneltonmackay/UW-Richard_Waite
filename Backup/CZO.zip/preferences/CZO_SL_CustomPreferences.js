/**
 * Module Description
 * Script for Company/User Custom Preferences
 *
 * Version    Date            Author           Remarks
 * 1.00       23 Aug 2022     CZO-MRC          Initial Development
 *
 * @NApiVersion 2.1
 * @NScriptType suitelet
 */
define([], () => {
    return {
        onRequest(context) {}
    };
});