function deleteRecords(recordType, recordID)
	{
		nlapiDeleteRecord(recordType, recordID); // Delete record
	}